# Getting started with benchmarking

To run the benchmarks you need a nightly rust toolchain.
Then you launch it with

    cargo +nightly bench --features=benchmarks
