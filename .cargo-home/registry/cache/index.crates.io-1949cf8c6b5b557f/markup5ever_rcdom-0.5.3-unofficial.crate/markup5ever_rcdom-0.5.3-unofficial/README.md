# markup5ever_rcdom

This crate is built for the express purpose of writing automated tests for the `html5ever`
and `xml5ever` crates. It is not intended to be a production-quality DOM implementation,
and has not been fuzzed or tested against arbitrary, malicious, or nontrivial inputs. No maintenance
or support for any such issues will be provided. If you use this DOM implementation in a production,
user-facing system, you do so at your own risk.
