getopts
===

A Rust library for option parsing for CLI utilities.

[Documentation](https://docs.rs/getopts)

## Usage

Add this to your `Cargo.toml`:

```toml
[dependencies]
getopts = "0.2"
```

## Contributing

The `getopts` library is used by `rustc`, so we have to be careful about not changing its behavior.
