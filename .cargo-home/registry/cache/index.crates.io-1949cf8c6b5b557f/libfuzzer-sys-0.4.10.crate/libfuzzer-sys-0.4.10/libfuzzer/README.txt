See http://llvm.org/docs/LibFuzzer.html
