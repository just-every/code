# Contributing to wasi-core

wasi-core follows the same development style as Cranelift, so checkout
[Cranelift's CONTRIBUTING.md]. Of course, for wasi-core-specific issues, please
use the [wasi-core issue tracker].

[Cranelift's CONTRIBUTING.md]: https://github.com/CraneStation/cranelift/blob/master/CONTRIBUTING.md
[wasi-core issue tracker]: https://github.com/CraneStation/wasi-core/issues/new
