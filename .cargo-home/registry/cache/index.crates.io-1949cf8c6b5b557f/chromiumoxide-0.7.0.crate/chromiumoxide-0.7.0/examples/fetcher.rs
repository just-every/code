use std::path::Path;

use futures::StreamExt;

use chromiumoxide::browser::{Browser, BrowserConfig};
use chromiumoxide::fetcher::{BrowserFetcher, BrowserFetcherOptions};

#[async_std::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    // Fetcher browser
    let download_path = Path::new("./download");
    async_std::fs::create_dir_all(&download_path).await?;
    let fetcher = BrowserFetcher::new(
        BrowserFetcherOptions::builder()
            .with_path(&download_path)
            .build()?,
    );
    let info = fetcher.fetch().await?;

    // Verify browser
    let (mut browser, mut handler) = Browser::launch(
        BrowserConfig::builder()
            .chrome_executable(info.executable_path)
            .build()?,
    )
    .await?;

    let handle = async_std::task::spawn(async move {
        loop {
            match handler.next().await {
                Some(h) => match h {
                    Ok(_) => continue,
                    Err(e) => {
                        println!("Err: {}", e);
                        break;
                    }
                },
                None => {
                    println!("None");
                    break;
                }
            }
        }
        println!("Done");
    });

    let page = browser.new_page("about:blank").await?;

    let sum: usize = page.evaluate("1 + 2").await?.into_value()?;
    assert_eq!(sum, 3);
    println!("it worked!");

    browser.close().await?;
    browser.wait().await?;
    handle.await;
    Ok(())
}
